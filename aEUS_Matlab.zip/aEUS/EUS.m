function [best_x, best_err, FEs] = EUS(current, D, max_FEs, fun, LB, UB, opt_f, err, F)
    x = zeros(3,D);
    y = zeros(3,1);

    h = UB - LB;

    best_x = current;
    best_err = func(best_x, fun, opt_f);
    
    y(2) = best_err;

    % No. of FEs
    FEs = 1;

    % Restart Procedure
    localOptima = [];
    
    while FEs < max_FEs && best_err >= err

        tmp = y(2);
        for i=1:1:D
            x(2,:) = current;
            x(1,:) = current;  % previous
            x(3,:) = current;  % next

            x(3,i) = x(2,i) + h(i);  % next
            x(1,i) = x(2,i) - h(i);  % previous

            x(1,:) = max(LB, x(1,:));
            x(1,:) = min(UB, x(1,:));

            x(3,:) = max(LB, x(3,:));
            x(3,:) = min(UB, x(3,:));
            
            y(1) = func(x(1,:), fun, opt_f);
            y(3) = func(x(3,:), fun, opt_f);

            FEs = FEs + 2;

            [y(2), current_index] = min(y);

            current = x(current_index,:);
        end

        if y(2) == tmp % The pass did not improve the fitness
            h = F * h;
        end

        if h < 1E-15
            %disp('RESTART');
            h = UB - LB;
            localOptima{length(localOptima) + 1} = current;
            current = restart(localOptima, 1000, LB, UB, D);
            y(2) = func(current, fun, opt_f);
        end
        
        if(y(2) < best_err) % if the best overall solution has been improved
            best_x = current;
            best_err = y(2);
        end
        
        if(best_err < err)
           break;
        end
    end
    fprintf('EUS best_err = %e\n', best_err)
end

function [x]= restart(localOptima, nbGen, LB, UB, D)
    dmax = 0;
    for i=1:1:nbGen
        y = zeros(1,D);
        for j=1:1:D
            y(j) = alea(LB(j),UB(j));
        end
        d = distanceToSet(y, localOptima);
        if(d > dmax) 
            x = y; 
            dmax = d;
        end
    end
end

function [d]= distanceToSet(x, set)
    d = Inf;
    for i=1:1:length(set)
        dtmp = 0;
        for j=1:1:length(x)
            dtmp = dtmp + (x(j) - set{i}(j))^2;
        end
        if(d > dtmp) 
            d = dtmp; 
        end
    end
end
    
    
        
        
        
        
        
        
        
    