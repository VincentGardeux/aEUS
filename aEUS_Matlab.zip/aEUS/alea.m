function r= alea (a,b)
% random number (uniform distribution) in [a b]
    
    r = a + rand*(b - a); 
 
end

