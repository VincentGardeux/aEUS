function f=benchmark_func_ISDA(x,func_num)
global initial_flag
persistent fhd
if initial_flag==0
    if func_num==7       fhd=str2func('schwefel_2_22'); % [-10, 10]
    elseif func_num==8   fhd=str2func('schwefel_1_2');  % [-65.536, 65.536]
    elseif func_num==9   fhd=str2func('extended_f_10'); % [-100, 100]
    elseif func_num==10  fhd=str2func('bohachevsky');   % [-15, 15]
    elseif func_num==11  fhd=str2func('schaffer');      % [-100, 100]
    end
end
f=feval(fhd,x);
end

% 7. Schwefel�s Problem 2.22 
function fit=schwefel_2_22(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load schwefel_2_22_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-10+20*rand(1,D);
    end
    initial_flag=1;
end
z=x-repmat(o,ps,1);
fit=sum(abs(z),2) + prod(abs(z),2);
end

% 8. Schwefel�s Problem 1.2
function fit = schwefel_1_2(x)
global initial_flag
persistent o
[ps, D] = size(x);
if (initial_flag == 0)
  load schwefel_1_2_data
  if length(o) >= D
      o=o(1:D);
  else
      o=-65.536+131.072*rand(1,D);
  end
  initial_flag = 1;
end
z=x-repmat(o,ps,1);
fit=0;
for i=1:D
    fit=fit+sum(z(:,1:i),2).^2;
end
end

% 9. Extended f10

%f10
function fit=f_10(x, y)
z = x^2 + y^2;
fit = z^(0.25) * (sin(50 * z^(0.1))^2 + 1);
end

function fit=extended_f_10(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load extended_f_10_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-100+200*rand(1,D);
    end
    initial_flag=1;
end
z=x-repmat(o,ps,1);
fit=f_10(z(D),z(1));
for i=1:D-1
    fit=fit+f_10(z(i),z(i+1));
end
end

% 10. Bohachevsky
function fit=bohachevsky(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load bohachevsky_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-15+30*rand(1,D);
    end
    initial_flag=1;
end
z=x-repmat(o,ps,1);
fit=0;
for i=1:D-1
    fit=fit + z(i)^2 + 2*z(i+1)^2 - 0.3*cos(3*pi*z(i)) - 0.4*cos(4*pi*z(i+1)) + 0.7;
end
end

% 11. Schaffer
function fit=schaffer(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load schaffer_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-100+200*rand(1,D);
    end
    o=o(1:D);
    initial_flag=1;
end
z=x-repmat(o,ps,1);
fit=0;
for i=1:D-1
    w = z(i)^2 + z(i+1)^2; 
    fit=fit + w^(0.25) * (sin(50*w^(0.1))^2 + 1);
end
end
%%%%% end of file %%%%%

