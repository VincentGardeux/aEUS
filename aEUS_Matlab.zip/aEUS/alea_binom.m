function zz = alea_binom(p,D) 
% Simulate the binomial distribution
% with the specific condition that the sample number can not be null
% Mean=p + (1-p)^n/n (not p as usually, because of the above condition)
% and normalise it.

    zz = 0;
        
    for d=1:1:D
        if (alea(0,1) < p)
            zz = zz + 1;
        end
    end %d
       
%     if zz<1
%         zz = 1;  % Be sure it can't be null
%     end
       
    zz = zz/D;
end