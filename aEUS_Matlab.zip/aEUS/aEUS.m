function [best_x, best_err, FEs] = aEUS(current, D, max_FEs, fun, LB, UB, opt_f, err)    
    %   aEUS(current, D, max_FEs, fun, LB, UB, opt_f, err)   
    %       Optimize the high-dimensional function "fun" using the aEUS
    %       algorithm.
	%   	"current" is the starting point
	%       "D" is the dimension
	%       "max_FEs" is the maximum allowed number of objective function
	%       evaluations
    %       "err" is the minimum error from which the solution is
    %       considered perfectly solved, thus stopping the optimization
    %       "opt_f" is the optimal value to reach (not used in the
    %       optimization process, but only as a stopping criterion)
    %       "LB" Lower Bound of the search space
    %       "UB" Upper Bound of the search space

    x = zeros(3,D);
    y = zeros(3,1);

    best_x = current;
    best_err = func(best_x, fun,opt_f);

    y(2) = best_err;
    
    h = (UB - LB); % * rand;
    
    F = 0.9; % same F for all dimensions
    old_Nr = Inf;
    Nr = 0;
    T = D;      % Temperature
    
    % No. of FEs
    FEs = 1;

    while best_err >= err && FEs < max_FEs
        % Start of a Block
        indexes = 1:D; % Dimensions to check on this pass (All at initial)
        while(~isempty(indexes)) % While the block is not finished
            to_remove = [];
            for j=1:1:length(indexes) % Check only dimensions in the "indexes" vector
                i = indexes(j); % dimension to check
                
                x(2,:) = current;
                x(1,:) = current;  % previous
                x(3,:) = current;  % next

                x(3,i) = x(2,i) + h(i);  % next
                x(1,i) = x(2,i) - h(i);  % previous

                x(1,:) = max(LB, x(1,:));
                x(1,:) = min(UB, x(1,:));

                x(3,:) = max(LB, x(3,:));
                x(3,:) = min(UB, x(3,:));

                y(1) = func(x(1,:), fun,opt_f); 
                y(3) = func(x(3,:), fun,opt_f);

                FEs = FEs + 2;

                [fit, current_index] = min(y);

                if fit==y(2)
                    to_remove = [to_remove; j];
                end % if no amelioration on this dimension, do not consider it on the next pass of this block
                
                current = x(current_index,:);
                y(2) = fit;
            end
            indexes(to_remove) = []; 
            Nr = Nr + 1; % I count the number of iterations in this block
        end %end of the block
        if fit < best_err % The block gave an improvement
           best_err = fit;
           best_x = current;
        else % Only 1 pass on a block, and no improvement
            if Nr == 1 && old_Nr == 1   % If two successive blocks give no improvement
                h = (UB - LB) * rand(); % I reset the h value
                F = rand();             % and the F value
                T = D;
            end
            F = F * exp(-T/D); % Accelerate the procedure after each unsuccesful block, but much less at each iteration (because of the temperature value)
            old_Nr = Nr;
            Nr = 0;
            h = h * F;
        end

        T = T * 0.9;
        
        if(best_err < err)
           break;
        end
    end
    
    fprintf('aEUS best_err = %e\n', best_err)
end
