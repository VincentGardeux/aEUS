clear; %Clear workspace

disp_fun;

fun = input('Select a function:');
D = input('Choose the dimension of the functions:');

fprintf('\nFunction #%d\n', fun)
fprintf('Dimension #%d\n\n', D)
    
Nr = 25; % No. of runs

[LB, UB, opt_f, err] = get_fun_info(fun,D);

global initial_flag;
initial_flag = 0;

SR0 = 0;
SR = 0;

tot_FE0 = 0;
tot_FE = 0;

s = 1000;

new_f0 = zeros(1,Nr);
new_f = zeros(1,Nr);

f = zeros(1,s);

if fun >= 54 && fun <= 64
    max_FEs = 5000*D;
else
    max_FEs = 1e5;
end

% Warm up the RNG
for t=1:1:10000
    zz=rand;
end

for r=1:1:Nr

    fprintf('r = %d\n', r);

     for i=1:1:s
        for j=1:1:D
            x(i,j) = alea(LB(j),UB(j));
        end
    end

     %calculate fitness
     for j = 1:1:s
         f(j) = func(x(j,:), fun, opt_f);
     end

     [best_f, best_index] = min(f);

     y = x(best_index,:);

     initial_flag = 0;

     [~, new_f0(r), FEs0] = EUS(y, D, max_FEs, fun, LB, UB, opt_f, err, 0.5);

     if new_f0(r) < err
         SR0 = SR0 + 1;
         tot_FE0 = tot_FE0 + FEs0;
     end
     
     [~, new_f(r), FEs] = aEUS(y, D, max_FEs, fun, LB, UB, opt_f, err);

     if new_f(r) < err
         SR = SR + 1;
         tot_FE = tot_FE + FEs;
     end
end %r

fprintf('\nEUS\n');
fprintf('Avg. fitness = %1.2e(%e) ', mean(new_f0), std(new_f0));
fprintf(' SR = %1.2e ', (SR0/Nr)*100);
fprintf(' FEs = %1.2e\n',tot_FE0/SR0);

fprintf('\naEUS\n');
fprintf('Avg. fitness = %1.2e(%e) ', mean(new_f), std(new_f));
fprintf(' SR = %1.2e ', (SR/Nr)*100);
fprintf(' FEs = %1.2e\n',tot_FE/SR);
