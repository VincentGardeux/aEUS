function ir = aleaInteger(a, b)

% Integer random number in [a,b]

    r = alea(a, b+1);
    
    ir = floor(r);
    
end
