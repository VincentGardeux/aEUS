package MetaHeuristic.aEUS;

import java.util.ArrayList;

import Heuristest.OSProject;
import Heuristest.Problem;
import MetaHeuristic.Heuristic;
import MetaHeuristic.EM323.Solution;

public class aEUS extends Heuristic 
{	
	public static Solution best; // The best solution found so far
	public static Solution current; // The current solution
	
	public ArrayList<Integer> indexes; // Set of dimensions for strategic oscillation method
	
	public double h;
	public double F;
	public int old_Nr;
	public int Nr;
	public double T;
	
	public aEUS() 
	{		
		// Initialize the iteration number
		iteration = 0;
		
		// Generate Random Initial Solution
		current = new Solution();
		for(int i = 0;i<Problem.dimension;i++) current.X[i] = Problem.initBounds[0] + OSProject.alea.nextDouble() * (Problem.initBounds[1] - Problem.initBounds[0]);
			
		// Compute Fitness
		current.fitness = calculateFitness(current.X);
		
		// Parameters
		h = Problem.initBounds[1] - Problem.initBounds[0];
		F = 0.9;
		old_Nr = Integer.MAX_VALUE;
		Nr = 0;
		T = Problem.dimension;
		
		// Initialize best
		best = current.clone();
	}

	
	/**
	 * Return the best solution
	 */
	public double[] best() 
	{
		return best.X;
	}
	
	/**
	 * One iteration of the global method
	 */
	public void iterate() 
	{
		iteration++;
			
		// Initialize set of dimensions
		indexes = new ArrayList<Integer>();
		for (int i = 0; i < Problem.dimension; i++) indexes.add(new Integer(i));
		double fit = current.fitness;
		// Start a block
		while(!indexes.isEmpty())
		{
			for(int i = 0;i<indexes.size();i++)
			{
				int j = indexes.get(i);
				// Generate neighbor Solutions
				Solution previous = current.clone();
				Solution next = current.clone();
				previous.X[j] = current.X[j] - h;
				if(previous.X[j] < Problem.searchSpaceBounds[0]) previous.X[j] = Problem.searchSpaceBounds[0];
				next.X[j] = current.X[j] + h;
				if(next.X[j] > Problem.searchSpaceBounds[1]) next.X[j] = Problem.searchSpaceBounds[1];
				previous.fitness = Heuristic.calculateFitness(previous.X);
				next.fitness = Heuristic.calculateFitness(next.X);
				if(current.fitness > previous.fitness || current.fitness > next.fitness)
				{
					if(previous.fitness < next.fitness) current.aff(previous);
					else current.aff(next);
				}
				else
				{
					indexes.remove(i);
					i--;
				}
			}
			Nr++;
		}
		// Block is finished
        if(fit == current.fitness) // assuming minimization; 1 pass on a block, and no improvement
        {
	       	if(Nr == 1 && old_Nr == 1)   // If two successive blocks give no improvement
	       	{
	       		h = OSProject.alea.nextDouble() * (Problem.initBounds[1] - Problem.initBounds[0]); // I reset the h value
	    		F = OSProject.alea.nextDouble();             // and the F value
	    		T = Problem.dimension;
	     	}
	       	F = F * Math.exp(-T/(double)Problem.dimension); // Accelerate the procedure after each unsuccesful block, but much less at each iteration (because of the temperature value)
	       	T = T * 0.1;
	       	old_Nr = Nr;
			Nr = 0;
	       	h = h * F;
        }
        if(current.fitness < best.fitness) best = current.clone();
	}
}

